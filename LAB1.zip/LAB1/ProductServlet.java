package com.poly.servlet;

import com.poly.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter; 
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = {"/product/index", "/product/create", "/product/edit/*", "/product/delete/*"})
public class ProductServlet extends HttpServlet {
    
    // Khởi tạo List sản phẩm dùng chung (Hardcode ArrayList)
    private static List<Product> listProducts = new ArrayList<>();

    @Override
    public void init() throws ServletException {
        // Thêm dữ liệu mẫu khi Servlet khởi chạy lần đầu
        if(listProducts.isEmpty()) {
            listProducts.add(new Product("P01", "iPhone 15 Pro Max", 1200));
            listProducts.add(new Product("P02", "Samsung Galaxy S24 Ultra", 1100));
            listProducts.add(new Product("P03", "MacBook Pro M3", 2000));
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String path = request.getServletPath();

        out.println("<html><head><title>Product Management</title></head><body>");

        // 1. /product/index -> Hiển thị danh sách sản phẩm
        if (path.equals("/product/index")) {
            out.println("<h2>Danh sách sản phẩm</h2>");
            out.println("<a href='" + request.getContextPath() + "/product/create'>Thêm sản phẩm mới</a><br><br>");
            out.println("<table border='1' cellpadding='8' style='border-collapse:collapse;'>");
            out.println("<tr><th>ID</th><th>Tên sản phẩm</th><th>Giá ($)</th><th>Hành động</th></tr>");
            for (Product p : listProducts) {
                out.println("<tr>");
                out.println("<td>" + p.getId() + "</td>");
                out.println("<td>" + p.getName() + "</td>");
                out.println("<td>" + p.getPrice() + "</td>");
                out.println("<td>");
                out.println("<a href='" + request.getContextPath() + "/product/edit/" + p.getId() + "'>Sửa</a> | ");
                out.println("<a href='" + request.getContextPath() + "/product/delete/" + p.getId() + "' onclick='return confirm(\"Chắc chắn xóa?\")'>Xóa</a>");
                out.println("</td>");
                out.println("</tr>");
            }
            out.println("</table>");
        } 
        
        // 2. /product/create -> Hiển thị form thêm mới sản phẩm
        else if (path.equals("/product/create")) {
            out.println("<h2>Thêm sản phẩm mới</h2>");
            out.println("<form action='" + request.getContextPath() + "/product/create' method='POST'>");
            out.println("Mã SP: <input type='text' name='id'><br><br>");
            out.println("Tên SP: <input type='text' name='name'><br><br>");
            out.println("Giá ($): <input type='number' name='price'><br><br>");
            out.println("<button type='submit'>Lưu lại</button>");
            out.println("</form>");
            out.println("<br><a href='" + request.getContextPath() + "/product/index'>Quay lại danh sách</a>");
        } 
        
        // 3. /product/edit/{id} -> Đọc Id từ Path Info và hiển thị dữ liệu cũ lên form
        else if (path.equals("/product/edit")) {
            String id = request.getPathInfo() != null ? request.getPathInfo().substring(1) : "";
            Product productEdit = null;
            for (Product p : listProducts) {
                if (p.getId().equals(id)) {
                    productEdit = p;
                    break;
                }
            }

            if (productEdit != null) {
                out.println("<h2>Cập nhật sản phẩm</h2>");
                out.println("<form action='" + request.getContextPath() + "/product/edit/" + productEdit.getId() + "' method='POST'>");
                out.println("Mã SP: <b>" + productEdit.getId() + "</b> (Không được sửa)<br><br>");
                out.println("Tên SP: <input type='text' name='name' value='" + productEdit.getName() + "'><br><br>");
                out.println("Giá ($): <input type='number' name='price' value='" + productEdit.getPrice() + "'><br><br>");
                out.println("<button type='submit'>Cập nhật</button>");
                out.println("</form>");
            } else {
                out.println("<p style='color:red;'>Không tìm thấy sản phẩm có mã: " + id + "</p>");
            }
            out.println("<br><a href='" + request.getContextPath() + "/product/index'>Quay lại danh sách</a>");
        } 
        
        // 4. /product/delete/{id} -> Xóa sản phẩm khỏi list
        else if (path.equals("/product/delete")) {
            String id = request.getPathInfo() != null ? request.getPathInfo().substring(1) : "";
            listProducts.removeIf(p -> p.getId().equals(id));
            // Xóa xong chuyển hướng về trang danh sách
            response.sendRedirect(request.getContextPath() + "/product/index");
            return;
        }

        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        // Xử lý nút bấm từ form tạo mới
        if (path.equals("/product/create")) {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            double price = Double.parseDouble(request.getParameter("price"));

            listProducts.add(new Product(id, name, price));
            response.sendRedirect(request.getContextPath() + "/product/index");
        } 
        // Xử lý nút bấm từ form cập nhật
        else if (path.equals("/product/edit")) {
            String id = request.getPathInfo() != null ? request.getPathInfo().substring(1) : "";
            String name = request.getParameter("name");
            double price = Double.parseDouble(request.getParameter("price"));

            for (Product p : listProducts) {
                if (p.getId().equals(id)) {
                    p.setName(name);
                    p.setPrice(price);
                    break;
                }
            }
            response.sendRedirect(request.getContextPath() + "/product/index");
        }
    }
}