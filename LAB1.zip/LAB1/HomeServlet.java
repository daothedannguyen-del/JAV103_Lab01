package com.poly.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/home/index", "/home/about", "/home/contact"})
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String path = request.getServletPath();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Home Servlet</title></head>");
        out.println("<body>");
        
        // Xử lý hiển thị dựa trên URL (Yêu cầu 1)
        if (path.equals("/home/index")) {
            out.println("<h1>Welcome to Home Page</h1>");
        } else if (path.equals("/home/about")) {
            out.println("<h1>About Us Page</h1>");
        } else if (path.equals("/home/contact")) {
            out.println("<h1>Contact Page</h1>");
        }
        
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        // Yêu cầu 2: Nếu truy cập bằng POST
        out.println("POST method is called");
    }
}