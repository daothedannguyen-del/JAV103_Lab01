package com.poly.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/login/form", "/login/check"})
public class LoginServlet extends HttpServlet {

    // 1. GET: /login/form -> Hiển thị form HTML
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Login Form</title></head>");
        out.println("<body>");
        out.println("<h2>Login Form</h2>");
        out.println("<form action='" + request.getContextPath() + "/login/check' method='POST'>");
        
        out.println("Username: <input type='text' name='username'><br><br>");
        out.println("Password: <input type='password' name='password'><br><br>");
        
        out.println("Gender: ");
        out.println("<input type='radio' name='gender' value='Male' checked> Male ");
        out.println("<input type='radio' name='gender' value='Female'> Female<br><br>");
        
        out.println("Hobbies:<br>");
        out.println("<input type='checkbox' name='hobbies' value='Reading'> Reading<br>");
        out.println("<input type='checkbox' name='hobbies' value='Music'> Music<br>");
        out.println("<input type='checkbox' name='hobbies' value='Sports'> Sports<br><br>");
        
        out.println("City: ");
        out.println("<select name='city'>");
        out.println("  <option value='Ha Noi'>Hà Nội</option>");
        out.println("  <option value='Da Nang'>Đà Nẵng</option>");
        out.println("  <option value='TP HCM'>TP HCM</option>");
        out.println("</select><br><br>");
        
        out.println("<button type='submit'>Submit</button>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }

    // 2. POST: /login/check -> Đọc và in dữ liệu dạng bảng
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8"); // Đọc tiếng Việt không lỗi font
        PrintWriter out = response.getWriter();

        // Đọc dữ liệu bằng getParameter() và getParameterValues()
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String city = request.getParameter("city");
        String[] hobbies = request.getParameterValues("hobbies"); // Nhiều checkbox

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Result</title></head>");
        out.println("<body>");

        // Kiểm tra password (Yêu cầu: nếu password != "123" -> báo lỗi)
        if (password == null || !password.equals("123")) {
            out.println("<h3 style='color:red;'>Báo lỗi: Mật khẩu không chính xác!</h3>");
            out.println("<a href='" + request.getContextPath() + "/login/form'>Quay lại</a>");
            out.println("</body></html>");
            return;
        }

        // In toàn bộ dữ liệu ra dạng bảng HTML
        out.println("<h2>Dữ liệu đã nhận (POST)</h2>");
        out.println("<table border='1' cellpadding='10' style='border-collapse:collapse;'>");
        out.println("<tr><th>Trường dữ liệu</th><th>Giá trị</th></tr>");
        out.println("<tr><td>Username</td><td>" + username + "</td></tr>");
        out.println("<tr><td>Password</td><td>" + password + "</td></tr>");
        out.println("<tr><td>Gender</td><td>" + gender + "</td></tr>");
        
        // Kiểm tra null khi checkbox không được chọn
        out.println("<tr><td>Hobbies</td><td>");
        if (hobbies != null && hobbies.length > 0) {
            out.println(String.join(", ", hobbies));
        } else {
            out.println("<span style='color:gray;'>Không chọn sở thích nào</span>");
        }
        out.println("</td></tr>");
        
        out.println("<tr><td>City</td><td>" + city + "</td></tr>");
        out.println("</table>");
        
        out.println("<br><a href='" + request.getContextPath() + "/login/form'>Quay lại Form</a>");
        out.println("</body>");
        out.println("</html>");
    }
}